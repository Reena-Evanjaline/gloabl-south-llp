import Home from "./Home";

export default function Page() {
  return (
    <main>
      <Home />
    </main>
  );
}
